from flask import Flask, render_template
from flask_socketio import SocketIO, emit

app = Flask(__name__)
socketio = SocketIO(app)

@app.route('/')
def index():
    return render_template('index.html')  # Interfaz de usuario

@socketio.on('offer')
def handle_offer(data):
    print("Oferta recibida:", data)
    emit('offer', data, broadcast=True)

@socketio.on('answer')
def handle_answer(data):
    print("Respuesta recibida:", data)
    emit('answer', data, broadcast=True)

@socketio.on('candidate')
def handle_candidate(data):
    print("Candidato ICE recibido:", data)
    emit('candidate', data, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, debug=True)
